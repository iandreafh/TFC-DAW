require('./lib/utils/time').default;
var TimePicker = require('./lib/components/TimePicker').default;

module.exports = TimePicker;
